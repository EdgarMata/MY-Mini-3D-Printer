#pragma once

#define OVERSAMPLE 3
#define INTERRUPT_PRIORITY 0

#include <pinmapping.h>
#include <time.h>
#include "lpc17xx_rit.h"
#include "lpc17xx_clkpwr.h"
#include "debug_frmwrk.h"
